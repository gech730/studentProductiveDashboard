function Products() {
  const api = import.meta.env.VITE_API_URL;

  return (
    <div>
      <h1>Products Page</h1>
      <p>Fetching from API: {api}</p>
    </div>
  );
}

export default Products;
