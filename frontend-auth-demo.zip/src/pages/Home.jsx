function Home() {
  return (
    <div>
      <h1>Home Page</h1>
      <p>Welcome to our demo website!</p>
    </div>
  );
}

export default Home;
